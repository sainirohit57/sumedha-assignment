import ProductListPage from "./components/ProductListPage";

function App() {
  return (
    <div className="app-layout">
      <ProductListPage />
    </div>
  );
}

export default App;
