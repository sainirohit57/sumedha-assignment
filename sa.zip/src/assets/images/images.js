import proImg01 from "./pro_img_1.webp";

export const images = {
  proImg01,
};
